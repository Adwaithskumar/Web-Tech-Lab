<?php
$stuid=$_POST['stuid'];
$email=$_POST['email'];
$stuage=$_POST['stuage'];
$stugender=$_POST['stugender'];
$stucourse=$_POST['stucourse'];
$stuaddress=$_POST['stuaddress'];

if(!empty($stuid) || !empty($email)  ||!empty($stuage) ||!empty($stugender) ||!empty($stucourse) ||!empty($stuaddress))
{
 $host="localhost";
 $dbUsername="root";
 $dbPassword="";
 $dbname="christ";

 $conn=new mysqli($host,$dbUsername,$dbPassword,$dbname);
 if(mysqli_connect_error()){
     die('Connection Error('.mysqli_connect_errno().')'. mysqli_connect_error());
 }
 else{
     $SELECT="SELECT email From stuinfo Where email=?";
     $INSERT="INSERT into stuinfo (stu-id,stu-name,age,gender,course,address) values('$stuid','$email','$stuage','$stugender','$stucourse','$stuaddress')";
    $stmt= $conn->prepare($SELECT);
     $stmt->bind_param("s",$email);
     $stmt->execute();
     $stmt->bind_result($email);
     $stmt->store_result();
     $stmt->fetch();
     $rnum=$stmt->num_rows;
     if($rnum==0)
     {
         $stmt->close();

         $stmt=$conn->prepare("INSERT into stuinfo (stu-id,stu-name,age,gender,course,address) values(?,?,?,?,?,?)");
         $stmt->bind_param("ssssss",$stuid,$email,$stuage,$stugender,$stucourse,$stuaddress);
         $stmt->execute();
         echo "New Record Inserted Successfully";
     }
     else{
         echo "You have already submitted your feedback for this store";
     }
 }
}
else{
    echo "All fields are required";
    die();
}
?>
